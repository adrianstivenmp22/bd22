<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hacer Pedido - Supermercado</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('ruta/a/tu/imagen.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        .form-container {
            background: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            margin-top: 50px;
            max-width: 400px;
        }
    </style>
</head>
<body>
    <div class="container mt-5 d-flex justify-content-center">
        <form method="post" class="form-container">
            <h2 class="text-center">Hacer Pedido</h2>
            <?php
            include 'db.php';

            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $id_usuario = $_POST["id_usuario"];
                $productos = json_decode($_POST["productos"], true); // Array de [id_producto, cantidad]

                $total = 0;
                foreach ($productos as $producto) {
                    $id_producto = $producto["id_producto"];
                    $cantidad = $producto["cantidad"];

                    $sql = "SELECT precio FROM Productos WHERE id='$id_producto'";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        $total += $row["precio"] * $cantidad;
                    }
                }

                $sql = "INSERT INTO Pedidos (id_usuario, fecha, total) VALUES ('$id_usuario', CURDATE(), '$total')";
                if ($conn->query($sql) === TRUE) {
                    $id_pedido = $conn->insert_id;
                    foreach ($productos as $producto) {
                        $id_producto = $producto["id_producto"];
                        $cantidad = $producto["cantidad"];

                        $sql = "INSERT INTO DetallePedido (id_pedido, id_producto, cantidad, precio) VALUES ('$id_pedido', '$id_producto', '$cantidad', (SELECT precio FROM Productos WHERE id='$id_producto'))";
                        $conn->query($sql);
                    }
                    echo "<div class='alert alert-success' role='alert'>Pedido realizado con éxito</div>";
                } else {
                    echo "<div class='alert alert-danger' role='alert'>Error: " . $sql . "<br>" . $conn->error . "</div>";
                }
            }
            ?>
            <div class="form-group">
                <label for="id_usuario">ID Usuario</label>
                <input type="number" class="form-control" id="id_usuario" name="id_usuario" required>
            </div>
            <div class="form-group">
                <label for="productos">Productos (JSON)</label>
                <textarea class="form-control" id="productos" name="productos" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Hacer Pedido</button>
        </form>
    </div>

    <div class="container mt-5">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Precio</th>
                    <th>Stock</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include 'db.php';

                $sql = "SELECT * FROM vista_productos";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['id']}</td>
                                <td>{$row['nombre']}</td>
                                <td>{$row['descripcion']}</td>
                                <td>{$row['precio']}</td>
                                <td>{$row['stock']}</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No hay productos</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
