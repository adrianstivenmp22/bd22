<?php
include 'db.php';

$sql = "SELECT * FROM vista_productos";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "ID: " . $row["id"] . " - Nombre: " . $row["nombre"] . " - Descripción: " . $row["descripcion"] . " - Precio: " . $row["precio"] . " - Stock: " . $row["stock"] . "<br>";
    }
} else {
    echo "No hay productos";
}
?>
